package creational.builder.bt5;

import java.util.ArrayList;
import java.util.List;

public class Book {
    String tuaDe, tacGia;
    int soTrang;
    List<String> danhSachChuong;

    private Book(Builder b) {
        this.tuaDe = b.tuaDe;
        this.tacGia = b.tacGia;
        this.soTrang = b.soTrang;
        this.danhSachChuong = b.danhSachChuong;
    }

    @Override
    public String toString() {
        return "Book " + '\n' +
                "+ tuaDe: " + tuaDe + '\n' +
                "+ tacGia: " + tacGia + '\n' +
                "+ soTrang: " + soTrang + '\n' +
                "+ danhSachChuong: " + danhSachChuong + '\n';
    }

    public static class Builder {
        private String tuaDe, tacGia;
        private int soTrang;
        private List<String> danhSachChuong;

        public Builder themTuaDe(String tuaDe) {
            this.tuaDe = tuaDe;
            return this;
        }

        public Builder themTacGia(String tacGia) {
            this.tacGia = tacGia;
            return this;
        }

        public Builder themSoTrang(int soTrang) {
            this.soTrang = soTrang;
            return this;
        }

        public Builder themDanhSachChuong(List<String> danhSachChuong) {
            this.danhSachChuong = danhSachChuong;
            return this;
        }

        public Book build() {
            return new Book(this);
        }

    }
}
