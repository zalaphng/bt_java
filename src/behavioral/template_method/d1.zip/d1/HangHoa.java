package behavioral.template_method.d1;

public class HangHoa{

    public String tenMH;
    public int soLuong;
    public double donGia;

    public HangHoa(String tenMH, int soLuong, double donGia){
        this.tenMH=tenMH;
        this.soLuong=soLuong;
        this.donGia=donGia;
    }
}
