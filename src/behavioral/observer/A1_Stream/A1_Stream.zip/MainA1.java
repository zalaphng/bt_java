package behavioral.observer.A1_Stream;

public class MainA1 {
    public static void main(String[] args) {
        Client subject = new Client();
        subject.getCourseStream().listen(new Client.CourseListener());
        subject.addCourse(new Course("Math"));
        subject.addCourse(new Course("English"));
        subject.updateCourse(0, new Course("Calculus"));
        subject.removeCourse(1);
    }
}