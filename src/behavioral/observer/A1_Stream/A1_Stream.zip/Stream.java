package behavioral.observer.A1_Stream;

import java.util.ArrayList;
import java.util.List;

public class Stream<T> {
    private List<T> events = new ArrayList<>();
    private List<IListener<T>> listeners = new ArrayList<>();

    public void addEvent(T t) {
        events.add(t);
        notifyListeners();
    }

    public void listen(IListener<T> l) {
        listeners.add(l);
    }

    private void notifyListeners() {
        for (IListener<T> l : listeners) {
            l.update(events);
        }
    }

    public static interface IListener<T> {
        void update(List<T> events);
    }
}
