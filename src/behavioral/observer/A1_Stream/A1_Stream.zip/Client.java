package behavioral.observer.A1_Stream;

import java.util.ArrayList;
import java.util.List;

public class Client {
    private List<Course> courses = new ArrayList<>();
    private Stream<List<Course>> courseStream = new Stream<>();

    public void addCourse(Course course) {
        courses.add(course);
        courseStream.addEvent(courses);
    }

    public void updateCourse(int index, Course course) {
        courses.set(index, course);
        courseStream.addEvent(courses);
    }

    public void removeCourse(int index) {
        courses.remove(index);
        courseStream.addEvent(courses);
    }

    public Stream<List<Course>> getCourseStream() {
        return courseStream;
    }

    static class CourseListener implements Stream.IListener<List<Course>> {
        @Override
        public void update(List<List<Course>> events) {
            List<Course> courses = events.get(events.size() - 1);
            System.out.println("List of courses:");
            for (Course course : courses) {
                System.out.println(course.getName());
            }
            System.out.println("--------------------");
        }
    }
}



